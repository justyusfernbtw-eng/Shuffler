# Shuffler — Vercel kurulumu

Bu klasör, Shuffler'ı kendi vercel.app adresinde yayınlaman için hazırlandı.
ShufflerShare (cihazlar arası paylaşım), claude.ai'deki "room" özelliği yerine
kendi küçük sinyalleşme uç noktasını (`api/signal.js`) kullanacak şekilde
uyarlandı. Shuffler'ın geri kalanı (yükleme, karıştırma, çalma vs.) zaten
tamamen istemci tarafında çalışıyor, ekstra bir şey gerekmiyor.

## Adımlar

1. Bu klasörü bir GitHub reposuna yükle (veya `vercel` CLI ile doğrudan deploy et).
2. [vercel.com](https://vercel.com) üzerinden bu repoyu bir proje olarak içe aktar.
   Framework olarak "Other" seçilebilir, özel bir ayar gerekmiyor.
3. Proje oluştuktan sonra Vercel panelinde **Storage** sekmesine git, **Create
   Database → KV (Upstash)** seç ve projene bağla. Vercel bunu yaptığında
   gerekli `KV_REST_API_URL` / `KV_REST_API_TOKEN` ortam değişkenlerini
   otomatik olarak projene ekler — elle bir şey girmen gerekmiyor.
4. Projeyi yeniden deploy et (KV bağlandıktan sonra bir redeploy gerekir).
5. Yayınlanan adrese gidip test et: bir cihazda "Paylaş" ile kod/QR oluştur,
   diğerinde "ShuffleShare ile şarkı al" ile kodu gir.

## Notlar

- KV olmadan da site açılır, şarkı yükleme/karıştırma/çalma normal çalışır;
  sadece ShufflerShare'de "kullanılamıyor" hatası alırsın. KV bağlamak
  tamamen ücretsiz bir Vercel eklentisi (Upstash Redis tabanlı, Hobby planda
  da var).
- Oda kodları 10 dakika sonra kendiliğinden siliniyor (KV TTL), yani eski
  kodlar ortalıkta kalmıyor.
- Hâlâ sadece STUN kullanılıyor (TURN sunucusu yok), yani aynı Wi-Fi'de
  güvenilir çalışır; çok kısıtlayıcı NAT'lı farklı ağlarda bağlantı
  kurulamayabilir.
- Aynı `index.html` claude.ai'de Artifact olarak açıldığında otomatik olarak
  `room` özelliğini kullanır; kendi sitende açıldığında ise otomatik olarak
  `/api/signal`'e düşer. Tek kod tabanı, iki ortamda da çalışır.
