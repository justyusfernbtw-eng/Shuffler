// ShufflerShare sinyalleşme uç noktası (Vercel KV kullanır).
// Her oda kodu için host ve guest tarafının en son "presence" (QR/kod, SDP teklif/cevap) bilgisini
// kısa süreliğine (10 dk) saklar; karşı tarafın verisini okumak için yoklama (polling) ile kullanılır.
const { kv } = require('@vercel/kv');

const TTL = 600; // saniye

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.status(204).end(); return; }

  const cleanCode = (c) => (c || '').toString().toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 16);

  if (req.method === 'POST') {
    let body = req.body;
    if (typeof body === 'string') { try { body = JSON.parse(body); } catch (e) { body = {}; } }
    const code = cleanCode(body && body.code);
    const role = body && body.role;
    const patch = (body && body.patch) || {};
    if (code.length < 4 || (role !== 'host' && role !== 'guest')) {
      res.status(400).json({ error: 'invalid code/role' });
      return;
    }
    const key = `sh:${code}:${role}`;
    let cur = {};
    try { cur = (await kv.get(key)) || {}; } catch (e) {}
    const next = Object.assign({}, cur, patch, { ts: Date.now() });
    try { await kv.set(key, next, { ex: TTL }); } catch (e) {
      res.status(500).json({ error: 'kv_unavailable' });
      return;
    }
    res.status(200).json({ ok: true });
    return;
  }

  if (req.method === 'GET') {
    const code = cleanCode(req.query.code);
    const role = (req.query.role || '').toString();
    if (code.length < 4 || (role !== 'host' && role !== 'guest')) {
      res.status(400).json({ error: 'invalid code/role' });
      return;
    }
    const otherRole = role === 'host' ? 'guest' : 'host';
    let other = null;
    try { other = await kv.get(`sh:${code}:${otherRole}`); } catch (e) {
      res.status(500).json({ error: 'kv_unavailable' });
      return;
    }
    res.status(200).json({ peer: other || null });
    return;
  }

  res.status(405).end();
};
